# Kacper Ecosystem — START HERE

## Purpose

This package gives Claude Code the product, architecture and historical context needed to work on a connected ecosystem consisting of:

- **Ogarniacz** — private personal organizer / system of record for daily life.
- **ECHO** — personal voice assistant and conversational interface.
- **Smart Home** — sensors, actuators and automations; Home Assistant may be used as an integration/dashboard layer.
- **Po Kapiemu** — public-facing brand and project/community hub.
- **Copilot Kacpra** — operational copilot for mentoring programs, freelancing and project work.

These are **not intended to become one giant application or one shared database**.

The target is a cooperating ecosystem with clear ownership boundaries and explicit integration contracts.

## Reading order for Claude Code

1. `01_ECOSYSTEM_VISION.md`
2. `07_INTEGRATION_ARCHITECTURE.md`
3. `08_DATA_OWNERSHIP_AND_PRIVACY.md`
4. relevant project files:
   - `02_OGARNIACZ.md`
   - `03_ECHO.md`
   - `04_SMART_HOME.md`
   - `05_PO_KAPIEMU.md`
   - `06_COPILOT.md`
5. `09_SHARED_AI_MEMORY_AND_AGENT_PLAYBOOK.md`
6. `10_REPOS_AND_CURRENT_STATE.md`
7. `11_ROADMAP.md`
8. `12_OPEN_DECISIONS.md`

Also read the existing product specification:
`Copilot_Kacpra_Specyfikacja_dla_Claude_Code_v1.0.pdf`

## Source-of-truth hierarchy

1. Explicit current user instruction.
2. Current repository state and tests.
3. Current project-specific contracts / AGENTS.md / ADRs.
4. This context pack.
5. Older conversation history and historical plans.

Do not overwrite working architecture only because an older document contains a different idea.

## Critical working rule

Before creating a new repository, store, sync engine, reminder engine, user model, AI memory layer or integration mechanism, first search for an existing canonical implementation.

## Timestamp

Context assembled: 2026-09-29.

Some implementation-state notes are historical snapshots. Re-audit each repository before changing code.
