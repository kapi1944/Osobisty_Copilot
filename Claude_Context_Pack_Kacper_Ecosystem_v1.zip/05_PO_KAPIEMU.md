# Po Kapiemu

## Role

“Po Kapiemu” is the public umbrella brand and project/community hub.

Accepted phrase:
**„Od pomysłu do prototypu — projekty po mojemu, czyli po Kapiemu.”**

Personal page:
**„O Kapim”**

Po Kapiemu is not intended as a simple blog/portfolio. It is a hub for projects, documentation, voting, comments, reviews and support.

## Project model

Projects are the top-level structure.

Categories include technical, music, blocks, experimental and community.

ECHO is an important technical project.

Other examples include DIY MIDI controller, block projects and Project LAB.

Budgets, code, files and documentation belong to each project.

## Major product areas

Historical plans:
Start, Projekty, Kategorie, Głosowania, Aktualności/Treści, Projekty społeczności, Recenzje/Testy/Porównania, Sprzęt i polecane, Wsparcie, Współpraca, FAQ, O Kapim, Konto, author/admin panel.

Reviews were accepted as a major module with categories:
hardware, applications, programs, gadgets, accessories, modules/parts, services/platforms.

## Community mechanics

Desired:
comments, replies, reactions, 1–5 ratings, following projects/categories, project notifications, moderated suggestions, community voting, funding goals, transparent affiliate links.

1000 votes is a trigger for review, not automatic implementation.

## Project lifecycle

Planned statuses:
pomysł, plan, prototyp, testy, wersja 1.0, poprawki, wersja 2.0, zakończony.

## UX direction

Historical/accepted:
- React + Vite + TypeScript frontend direction,
- desktop left sticky sidebar,
- mobile compact navigation/hamburger,
- light/dark/system theme,
- compact/full modes,
- category accents,
- dark/neutral base and bright typography,
- avoid copying Gamma,
- avoid brown-dominated identity.

Historical snapshot: frontend MVP/demo existed; backend/auth/real data were not yet mature. Re-audit current repo.

## Privacy boundary

Po Kapiemu is a public projection layer.

It may receive curated:
project status, progress, changelog, artifacts, roadmap, reviews, polls and media.

It must not automatically receive:
private Ogarniacz tasks, health, finances, reminders, Copilot private sources, mentor emails, client confidential data, Smart Home security/occupancy data.

Publishing should be explicit and reviewed.
