# Data ownership and privacy

## Canonical ownership

- personal tasks/daily plan/reminders → Ogarniacz
- medication log/appointments/finances/car/shopping → Ogarniacz
- work research/mentor instructions/work artifacts → Copilot
- short dialogue session state → ECHO
- device/sensor state and automation config → Smart Home
- public projects/votes/reviews/community content → Po Kapiemu

## Never sync by convenience

Do not copy a whole dataset to obtain one field.

Prefer projections, APIs, source refs, events or small caches with updatedAt.

## Private categories

Health, finances, private notes/contacts, credentials, security state, confidential client info, mentor/private program material and unpublished business research are private.

## Public publishing

Data becomes public only through explicit publication/review.

## AI minimization

When ECHO asks “what now?”, provide current action/context only, not whole histories/databases.

## Logs

Do not log tokens/passwords or unnecessary raw private bodies/audio by default.
