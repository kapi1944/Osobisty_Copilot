# Master prompt for Claude Code — ecosystem audit

Read this entire context pack in the order from `00_START_HERE.md`.

Also read:
`Copilot_Kacpra_Specyfikacja_dla_Claude_Code_v1.0.pdf`

Do NOT start merging repositories or building a universal platform.

Your first job is to compare documented intent with the actual repositories.

When local Claude Code access is available, audit:
1. Ogarniacz
2. Po Kapiemu
3. all ECHO-related code
4. Smart Home / Home Assistant / GardenOS code/configuration
5. Copilot Kacpra

For every repo, record:
- path,
- branch/HEAD,
- working tree,
- stack,
- persistence,
- auth,
- APIs,
- source-of-truth stores,
- integrations,
- tests,
- AGENTS/ADRs/docs,
- worktrees/unmerged branches where relevant.

Search for collisions:
- duplicate task models,
- duplicate reminder engines,
- duplicate sync engines,
- duplicate AI memory,
- direct DB coupling,
- duplicated auth,
- duplicated device logic,
- private/public data leakage.

Then create only:
- ECOSYSTEM_AUDIT.md
- ECOSYSTEM_ACTUAL_ARCHITECTURE.md
- ECOSYSTEM_TARGET_ARCHITECTURE.md
- INTEGRATION_CONTRACTS_DRAFT.md
- DATA_OWNERSHIP_MATRIX.md
- RISK_REGISTER.md
- IMPLEMENTATION_ROADMAP.md

Constraints:
- Ogarniacz remains private personal system of record.
- Copilot remains operational work/knowledge system.
- ECHO is voice/dialogue/router, not a second database.
- Smart Home owns device/physical state.
- Po Kapiemu is public and receives curated data only.
- integrate through projections/commands/events, not shared DB tables.
- cross-system writes need explicit policy and audit.
- important/destructive/external actions require confirmation.
- preserve local-first where established.
- do not create parallel mechanisms when a canonical one exists.
- current repo state and current user instruction override historical documentation.

After producing the audit and target architecture, STOP.
Do not modify production logic until Kacper approves the integration architecture.
