# Integration architecture

## Primary rule

Integrate through contracts, not database access.

## Three integration forms

### Projections
Small read models, e.g. TodaySummary, CurrentWorkFocus, NextAction, SafeStatusSummary, PublicProjectSnapshot.

### Commands
Explicit requests, e.g. CreatePersonalTask, ScheduleReminder, OpenCopilotTask, RunSmartHomeScene, PublishProjectUpdate.

### Events
Facts that already happened, e.g. task.completed, reminder.snoozed, copilot.task.progressed, smarthome.device.offline, project.release.published.

## Recommended event envelope

```json
{
  "eventId": "uuid",
  "eventType": "copilot.task.progressed",
  "schemaVersion": 1,
  "occurredAt": "2026-09-29T12:00:00+02:00",
  "sourceSystem": "copilot",
  "sourceRef": "TAKEDROP-001",
  "correlationId": null,
  "actor": "user|system|echo|automation",
  "payload": {}
}
```

This is a proposed future contract, not an existing one.

## References

Prefer `sourceSystem + sourceRef` over copying foreign records.

## Permissions

ECHO gets limited projections.
Copilot gets only approved personal context.
Ogarniacz gets lightweight Copilot task projections.
Po Kapiemu gets curated publish-only data.
Smart Home receives approved commands.

## Important actions

Sending, publishing, payment/purchase, durable deletion, security/access actions and hazardous physical actions require confirmation.

## Deployment

Services may run on one Raspberry Pi while remaining logically separate.
