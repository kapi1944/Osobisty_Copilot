# Cross-ecosystem roadmap

## Phase 0 — audit

Audit Ogarniacz, Po Kapiemu, ECHO code, Smart Home/HA/GardenOS material and new Copilot repo.

Produce real repo map, ownership matrix and duplicate-mechanism list.

## Phase 1 — read-only projections

Ogarniacz: TodaySummary / NextPersonalAction.
Copilot: CurrentWorkFocus / NextWorkAction.
Smart Home: SafeStatusSummary.
Po Kapiemu: PublicProjectSnapshot.

## Phase 2 — ECHO router

ECHO answers cross-system questions by asking canonical owners.

## Phase 3 — approved writes

Examples:
Copilot → lightweight Ogarniacz task,
ECHO → snooze/complete personal task,
ECHO → safe Smart Home scene,
approved project update → Po Kapiemu draft.

Audit every cross-system write.

## Phase 4 — events

Only after APIs are stable:
versioned events, retries, idempotency, dedupe, correlation IDs, local queue/outbox if needed.

Do not add heavy brokers prematurely.

## Phase 5 — proactive assistance

ECHO initiates short planning conversations using concise Ogarniacz + Copilot projections and persists accepted changes to canonical owners.

## Phase 6 — curated public pipeline

Po Kapiemu consumes approved project status/changelog/artifacts/reviews/case studies.

## Phase 7 — broader Smart Home automation

Add safe routine/scene integration, maintenance reminders, telemetry analysis and GardenOS evolution.
