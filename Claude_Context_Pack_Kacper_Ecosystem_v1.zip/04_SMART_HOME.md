# Smart Home

## Role

Smart Home is the physical sensing and execution layer.

It owns device/sensor state, actuators, scenes, safe automations and telemetry.

It should not own Kacper’s work tasks or personal schedule.

## Earlier architecture direction

From the garden automation work, a useful pattern emerged:

Home Assistant / integrations/dashboard
→ custom decision service
→ ESP32
→ sensors/actuators

Home Assistant is optional and can accelerate integration; it does not automatically have to be the final intelligence layer.

## GardenOS direction

Known earlier ideas:
- Raspberry Pi 4,
- ESP32,
- HA/ESPHome early integration,
- later custom Python “GardenOS”,
- local and modular automation.

Known areas:
soil moisture, temperature/humidity, watering, lighting, ventilation, adjustable panel height, later cameras/growth analysis.

Watering preference: deep watering followed by drying, not permanent saturation.

## Integration rules

ECHO may query state and request actions through policy.
Ogarniacz may provide schedules/reminders that influence automation.
Copilot may design automations or analyze exported telemetry.
Po Kapiemu may publish curated project information.

No private household data should be published automatically.

## Safety

Define safe reboot defaults, manual override, failure modes, offline behavior, device health, watchdogs, action permissions and audit for important actions.

## Deployment

Raspberry Pi may host multiple services, but deployment co-location must not become architectural coupling.
