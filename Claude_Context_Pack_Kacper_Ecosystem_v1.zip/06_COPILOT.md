# Copilot Kacpra

## Role

Copilot is the operational knowledge-work layer for mentoring, courses, freelancing, research and project work.

It should be one system with many domains, not a separate assistant for every topic.

Architecture:
**one Core + many Domain Packs + Task Workspaces**

Initial domains:
TakeDrop and Akcelerator AI.

## Workflow

instruction/source → Interpreter → Task Card → Workspace Generator → Execution → Quality Gate → Handoff → Feedback Loop

## Concepts

Domain, Source, KnowledgeItem, Task, TaskCriterion, WorkspaceTool, RecordSet, WorkRecord, Decision, ParkingItem, Feedback, Artifact, Event, provenance.

Provenance:
MENTOR, USER, DATA, INFERENCE, SUGGESTION, ASSUMPTION.

## Anti-distraction

Classify side activity as:
POTRZEBNE TERAZ, PARKING or ROZPRASZACZ.

## Dynamic workspace

Create only what the task needs:
checklist, table, ranking, matrix, tests, calculator, chart, research list, notes, final document.

## Relationship with Ogarniacz

Copilot owns rich work context, sources, research, scoring, work decisions and artifacts.

Ogarniacz owns personal commitment, daily schedule, reminder/deadline and cross-life prioritization.

Integration should send a small task projection rather than copy a whole research workspace.

## Relationship with ECHO

ECHO can request:
current work task, next action, blocker, deadline, latest mentor feedback summary.

Use compact projections.

## Relationship with Po Kapiemu

Selected Copilot work may become public content/case studies only through explicit publication.

## Detailed specification

Use:
`Copilot_Kacpra_Specyfikacja_dla_Claude_Code_v1.0.pdf`

for the dedicated MVP architecture and implementation plan.
