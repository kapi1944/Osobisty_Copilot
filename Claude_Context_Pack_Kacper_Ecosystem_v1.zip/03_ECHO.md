# ECHO

## Role

ECHO is Kacper’s personal voice assistant.

Accepted ecosystem model:

> **Ogarniacz = memory and planner**  
> **ECHO = voice, dialogue, intelligence and suggestions**  
> **Smart Home = executor / physical hands**

ECHO should not become another heavy data store.

## Desired behavior

An accepted requirement:
ECHO should regularly initiate short conversations on its own to help plan the day.

This is not only a passive command parser.

## ECHO as gateway

Recommended routing model:

- personal planning → Ogarniacz,
- project/work questions → Copilot,
- home state/actions → Smart Home,
- public project info → Po Kapiemu.

ECHO should query canonical owners rather than keep duplicates.

## Project identity

Within Po Kapiemu, ECHO has been treated as a major technical project:
- personal voice assistant,
- AI,
- voice,
- Home Assistant/integrations,
- prototype,
- smart-home integration,
- own character/style of operation.

## Existing Ogarniacz hints

Prior Ogarniacz work referenced:
- `src/services/echo/*`,
- `DostawcaSesjiEcho`,
- `ustaleniaGlosowe`,
- voice/dashboard integrations.

Audit those before creating a second interface.

## Autonomy

Read/explain can be automatic for authorized data.
Suggest and prepare actions are encouraged.
Important external/destructive/physical actions require confirmation.

## Durable state

Temporary session context may belong to ECHO.
Durable facts should be stored by canonical owners:
Ogarniacz, Copilot, Smart Home, Po Kapiemu.

## Open choices

Do not assume decisions exist for:
wake word, STT, TTS, local/cloud inference, microphones/endpoints, retention, voice auth, exact runtime topology.
