# Repositories and known state

This is a navigation aid, not a substitute for a fresh audit.

## Ogarniacz

Known local path:
`C:\GitHub\Projects\Ogarniacz\Ogarniacz`

Known repair worktree:
`C:\GitHub\worktrees\Ogarniacz-fix-web-sync-ota`

September 2026 work included web settings fixes, sync/OTA, Android, form consistency and Echo-related files in at least one branch/worktree.

Late September Raspberry Pi systemd update-timer work also existed.

Before new work inspect main, worktrees, branches, server, sync provider selection and OTA docs.

## Po Kapiemu

Known repo name historically:
`kapi1944/Po_Kapiemu`

Historical stack snapshot:
React 19 + Vite 8 + TypeScript + routing, frontend MVP/demo, backend/auth/data not yet mature.

Re-audit.

## ECHO

Exists conceptually as a Po Kapiemu project and partially in Ogarniacz integration code.

Do not create a new canonical repo before locating current Echo code.

## Smart Home / GardenOS

Known direction:
Raspberry Pi 4, optional Home Assistant, ESPHome/ESP32, custom Python decision service later.

Canonical repo not established in this context.

## Copilot Kacpra

New project to bootstrap from scratch.

Detailed PDF spec already exists.
