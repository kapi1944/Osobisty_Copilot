# Ogarniacz

## Product role

Ogarniacz is the private personal system of record and planning layer.

Its purpose is to reduce the amount Kacper must remember and manually coordinate.

Canonical areas include personal tasks, reminders, daily planning, appointments, medication instructions/logs, finances, shopping, car records, notes, habits/goals where implemented.

ECHO should talk to this data, not duplicate it.

## Repository

Known local repository:
`C:\GitHub\Projects\Ogarniacz\Ogarniacz`

Known September 2026 repair worktree:
`C:\GitHub\worktrees\Ogarniacz-fix-web-sync-ota`

Re-audit current main, branches and worktrees before changes.

## Technical direction

Known architecture evolved toward:
- React + TypeScript + Vite,
- PWA,
- offline/local-first,
- Dexie / IndexedDB,
- domain/repository layers,
- Capacitor 8 Android shell,
- Android Local Notifications,
- synchronization abstraction,
- conflict handling,
- stable installation identity,
- versioned backup/restore,
- Raspberry Pi 4 8 GB as 24/7 server target,
- Node.js + TypeScript + Fastify + SQLite/WAL server direction,
- Tailscale/private deployment during development,
- OTA/update mechanism under active hardening.

## Product areas

Historically planned and/or implemented:
- Dzisiaj / Pulpit,
- Poczekalnia,
- Zadania,
- Planer dnia,
- Grafik / czas,
- Leki,
- Wizyty,
- Finanse / rachunki,
- Notatki,
- Zakupy,
- Samochód,
- Nawyki,
- Cele,
- Ustawienia,
- backup / restore,
- sync,
- reminders / notification history.

Implementation maturity varies; inspect current code.

## Dashboard philosophy

“Dzisiaj” should show things requiring action now.

The dashboard should aggregate canonical sources instead of creating shadow copies.

Source references should deep-link back to canonical items.

## Reminder architecture

Do not create a reminder engine per module.

Use a central Reminder Engine. Android scheduling should be a thin native layer, not a second business rules engine.

Medication reminders are organizational only. Ogarniacz must not diagnose or choose doses.

## Backup / restore pattern

Established direction:
- versioned manifest,
- app/schema versions,
- record counts,
- SHA-256 checksum over canonicalized payload,
- secrets removed,
- validation before restore,
- compatibility checks,
- automatic “before restore” backup,
- selective restore,
- explicit migrations.

Known backup sections:
Ustawienia, Zadania/Planer, Notatki, Poczekalnia, Leki + log, Wizyty, Finanse/rachunki, Samochód, Zakupy.

Rule: destructive data transformations should create a recoverable checkpoint first.

## Sync architecture

- local-first UI,
- UI independent from backend implementation,
- incremental upload/download,
- updatedAt,
- tombstones,
- stable cursor/revision,
- idempotent retries,
- installationId is not authentication,
- no silent server last-write-wins over client conflict logic,
- Blob transport should not use Base64 as database format,
- no hardcoded Pi IP.

## Android direction

- shared React/Vite/PWA core + Capacitor,
- Galaxy S23+ as reference device, but responsive smaller devices,
- Local Notifications channels,
- lifecycle/haptics/share/file bridges,
- deep links,
- Today widget snapshot bridge,
- native widget consumes prepared snapshot only,
- widget projection/cache never becomes source of truth.

## Security direction

Historically desired:
- app password,
- module codes,
- biometrics,
- Gość / Edytor roles,
- encrypted sync,
- logging/audit.

Verify current implementation.

## Ecosystem integration

Ogarniacz should expose small projections, not its whole DB.

Inbound example:
Copilot may create a lightweight Ogarniacz task/deadline after approval.

Outbound examples:
Today summary, next due task, reminder, appointment summary, current focus.
