# Open decisions

## Ecosystem
- shared integration gateway vs direct APIs?
- service authentication?
- global ID/reference strategy?
- location of integration audit logs?

## Ogarniacz
- exact current Pi backend status?
- current auth model?
- encrypted sync maturity?
- exact module completeness?
- unmerged worktree/branch changes?
- final OTA architecture?

## ECHO
- canonical repo?
- STT/TTS?
- wake word?
- local/cloud inference?
- retention?
- microphone/room endpoints?
- voice authentication?
- proactive interaction windows?

## Smart Home
- long-term role of Home Assistant?
- first device domains?
- MQTT vs HA APIs vs custom HTTP?
- safety classes/manual overrides?
- exact GardenOS boundary?

## Po Kapiemu
- current backend/auth/hosting?
- admin/CMS scope?
- publication API?
- moderation flow?
- public artifact policy?

## Copilot
- when does work task create personal task?
- minimum projection fields?
- completion sync?
- automatic projection or suggested projection first?
