# Glossary

Ogarniacz — private life-management system and canonical personal organizer.

ECHO — voice/conversational assistant and router.

Smart Home — physical sensing/actuation layer.

Home Assistant — optional integration/dashboard layer.

GardenOS — earlier concept for a custom local garden automation service.

Po Kapiemu — public umbrella brand and project/community platform.

O Kapim — personal/about section of Po Kapiemu.

Copilot Kacpra — operational copilot for mentoring, courses, freelancing and knowledge work.

Domain Pack — domain-specific knowledge/configuration used by Copilot Core.

Task Workspace — working area for one concrete Copilot task.

Projection — small read model intentionally shaped for another system.

SourceRef — stable reference to data owned by another system.

Parking — useful idea intentionally kept outside the current task.

Quality Gate — completion checks before a task is considered done.

Provenance — where a rule, fact, suggestion or inference came from.
