# Ecosystem vision

## One ecosystem, several products

The long-term goal is not a single all-in-one app.

> **Ogarniacz remembers and plans.  
> ECHO talks, interprets and helps.  
> Smart Home executes in the physical world.  
> Copilot organizes knowledge work and project execution.  
> Po Kapiemu publishes selected project output to the outside world.**

Each system should remain useful on its own.

## Core outcomes

The ecosystem should reduce manual remembering, repeated data entry, context switching, lost decisions, duplicated tooling and busy work.

It should improve next-action visibility, continuity between desktop/phone/voice, reminders, planning, reuse of confirmed knowledge, traceability and safe automation.

## Architectural principles

1. One canonical owner per category of data.
2. No shared databases by default.
3. Local-first where it matters.
4. Human control over important actions.
5. Minimal necessary context.
6. Strict public/private boundary.
7. Progressive automation.
8. One canonical mechanism per concern.

## What should NOT happen

Avoid:
- merging all repositories merely because the products cooperate,
- one universal mega-database,
- ECHO duplicating Ogarniacz tasks,
- Smart Home becoming the owner of schedule/work data,
- Copilot duplicating the full personal planner,
- Po Kapiemu reading private stores,
- AI silently sending/publishing/buying/deleting.
