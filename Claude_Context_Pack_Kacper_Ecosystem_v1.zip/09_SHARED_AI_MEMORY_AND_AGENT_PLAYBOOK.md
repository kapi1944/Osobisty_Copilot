# Shared AI memory and agent playbook

## Goal

Avoid AI repeatedly rediscovering the same architectural lessons.

Use:
- thin AGENTS.md for procedure,
- structured technical memory for confirmed knowledge.

## Suggested structure

docs/ai/
  decisions/
  fixes/
  contracts/
  runbooks/
  regressions/
  index.json

## Fix-note structure

Store:
symptom → root cause → canonical solution → tests → do_not_repeat → commit → confidence.

## Retrieval order

1. current module fix notes,
2. git log by symptom,
3. history of affected files,
4. analogous mechanism in the same repo,
5. analogous mechanism in another Kacper repo,
6. design from scratch only after that.

## Agent rules

- confirm repo and HEAD,
- find source of truth first,
- no parallel mechanism,
- after two failed implementation attempts return to diagnosis,
- do not run fallback after partial success unless proven safe,
- backup before destructive change,
- run relevant tests/lint/build and git diff --check,
- record reusable confirmed fixes.

## Confidence

Use confirmed / observed / hypothesis.

Only confirmed knowledge should become reusable “do not repeat” guidance.
